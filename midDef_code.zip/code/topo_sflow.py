#!/usr/bin/env python
#multi controller
#clear && ryu-manager multipath.py  --observe-links --verbose --ofp-tcp-listen-port 6633
#clear && ryu-manager ryu_multipath.py --observe-links --ofp-tcp-listen-port 6633
#sudo mn --topo linear,4 --controller remote,port=6634
#sudo mn ~/sflow-rt/extras/sflow.py --topo linear,4 depth=2,fanout=2, --controller remote,port=6634
#sudo mn --custom sflow-rt/extras/sflow.py --link tc,bw=10 \ --controller=remote,ip=127.0.0.1 --topo tree,depth=2,fanout=2
#sudo mn --custom ~/sflow-rt/extras/sflow.py --link tc,bw=10 --topo tree,depth=2,fanout=2

from mininet.cli import CLI
from mininet.net import Mininet
from mininet.node import RemoteController
from mininet.term import makeTerm


# Compile and run sFlow helper script
# - configures sFlow on OVS
# - posts topology to sFlow-RT
#execfile('~/sflow-rt/extras/sflow.py') 

with open('/home/sahaj/sflow-rt/extras/sflow.py') as infile:
    exec(infile.read())
    

if '__main__' == __name__:
    net = Mininet(controller=RemoteController)

    c0 = net.addController('c0', port=6634)
    c1 = net.addController('c1', port=6635)


    s1 = net.addSwitch('s1')
    s2 = net.addSwitch('s2')
    s3 = net.addSwitch('s3')
       

    h1 = net.addHost('h1',mac='00:00:01:00:00:00')  
    h2 = net.addHost('h2',mac='00:00:02:00:00:00')
    h3 = net.addHost('h3',mac='00:00:03:00:00:00')
    h4 = net.addHost('h4',mac='00:00:04:00:00:00')
    #h5 = net.addHost('h5',mac='00:00:05:00:00:00')
    

    net.addLink(s1, h1)
    net.addLink(s1, s2)
    net.addLink(s1, s3)
    net.addLink(s2, h2)
    net.addLink(s2, h3)
    net.addLink(s3, h4)
   # net.addLink(s3, h5)



    net.build()
    c0.start()
    s1.start([c0])
    
    c1.start()
    s1.start([c1])
        
    
    #net.startTerms()

    CLI(net)

    net.stop()


########C0   C1#############
#########\###/#############
###########S1#############
##########/|\#############
########h1 | \############
##########s2##s3############
#########/#\##/#\##########
########/###\h4##h5##########
#######/#####\##############
######h2######h3###########